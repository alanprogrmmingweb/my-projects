let display = document.getElementById("display");
const equal = document.getElementById("equal");
let body = document.querySelector("body");

let clickCount = 0;
equal.onclick = function() {
  clickCount++;

if(clickCount == 1) {
  display.innerHTML= "loading...";
  
  setTimeout( function(){
    
    display.innerHTML = `ask ChatGPT bro<img src="skullEmoji.png">
                                    <img src="prayEmoji.png">
                                    🥀`;
                                    
  }, 3000),
  setTimeout( function(){
      
      display.innerHTML = `pls let me alone<img src="skullEmoji.png">
                                    <img src="prayEmoji.png">
                                    🥀`;
                                    ;
    } , 5500)
    setTimeout( function(){
      
      display.innerHTML = "";
    } , 8000)

}


else if(clickCount == 2) {
  
  setTimeout( function(){
      
      display.innerHTML = `can't you read?<img src="skullEmoji.png">
                                    <img src="prayEmoji.png">
                                    🥀`;
                                    ;
    } , 0)
    
    clickCount = 0;
}
}